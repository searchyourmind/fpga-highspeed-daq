# FPGA Stream -> DDR -> PCIe Learning Lab (Week 1)

**Simulation-only training project. No board, FPGA synthesis, DDR controller,
PCIe endpoint, device driver, or hardware validation is claimed.**

This is a **learning starter**, not a completed deliverable. You implement a
16-bit-wide, 8-deep synchronous FIFO, then test it with Python/cocotb. The
counter lab is complete so you can verify the toolchain first. The FIFO RTL
has deliberate TODO sections, and its tests intentionally fail until completed.

## Setup (macOS / Homebrew)

```sh
xcode-select --install       # only if developer command-line tools are missing
brew install verilator python
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
verilator --version          # Verilator >= 5.036 for cocotb 2.0
cocotb-config --version
```

If you already have suitable Python/Clang/Make, reuse them instead of installing.
Windows: use a Linux/WSL environment; Linux: install Python, Make, GCC/C++, Verilator.

## Run

```sh
make smoke     # Day 1: expected PASS (counter)
make fifo      # Day 3-5: expected FAIL until you implement rtl/stream_fifo.sv
make lint      # Report any warnings or errors; tests alone are not enough
```

For simulator support and file conventions, see the official cocotb documentation:
https://docs.cocotb.org/en/v2.0.0/quickstart.html
https://docs.cocotb.org/en/v2.0.0/simulator_support.html

## What you should implement

`rtl/stream_fifo.sv` has five TODOs. You implement write/read pointers and
occupancy changes according to valid/ready transfers. Do not make the tests
pass by changing their assertions. If a test fails, inspect the correct
handshake at the rising edge, pointer motion and Python reference queue.

See [`docs/week1_tasks.md`](docs/week1_tasks.md) for seven daily exercises and
[`docs/architecture.md`](docs/architecture.md) for signal definitions.

## Scope boundaries

The FIFO uses a register array with combinational output read. It is **not**
a true DDR memory PHY, DDR controller, or PCIe endpoint. Later modules may
consume this FIFO using a similar ready/valid style; that does not prove an
actual AXI, PCIe, or DDR standard implementation. We will distinguish behavioral
transaction models, FPGA IP cores, timing analysis, and physical-layer work.

## Personal checklist

- [ ] Day 1 counter PASS on my machine
- [ ] Day 2 I can explain sequential vs combinational logic
- [ ] Day 3 write-pointer logic implemented
- [ ] Day 4 complete FIFO behavior implemented
- [ ] Day 5 all FIFO tests PASS under backpressure
- [ ] Day 6 DDR/PCIe position diagram written
- [ ] Day 7 results and waveform documented, Git commit created
