`timescale 1ns/1ps

// WEEK 1 EXERCISE: Implement this synchronous, single-clock ready/valid FIFO.
// For learning simplicity, keep DEPTH a power of two (default 8).
// This is a register-array FIFO, NOT a DDR memory controller or PCIe endpoint.
//
// Contract:
//  * A transfer at input happens ONLY when s_valid && s_ready at rising clk.
//  * A transfer at output happens ONLY when m_valid && m_ready at rising clk.
//  * When m_valid && !m_ready, m_data and m_valid must remain stable.
//  * reset clears occupancy and pending output (contents need not be cleared).
//  * Simultaneous accepted read/write preserves occupancy.
//  * Simplicity: no fall-through on empty; when full, reject pushes even if a pop
//    is accepted on the same cycle (legal, but not peak-throughput optimized).
//
// Intentional TODO: this file ELABORATES but is NOT FUNCTIONAL yet.
// make fifo is EXPECTED TO FAIL until you implement the next-state logic.
module stream_fifo #(
    parameter int DATA_W = 16,
    parameter int DEPTH  = 8
) (
    input  logic                            clk,
    input  logic                            rst_n,
    input  logic [DATA_W-1:0]               s_data,
    input  logic                            s_valid,
    output logic                            s_ready,
    output logic [DATA_W-1:0]               m_data,
    output logic                            m_valid,
    input  logic                            m_ready,
    output logic [$clog2(DEPTH+1)-1:0]     occupancy
);
    localparam int PTR_W = $clog2(DEPTH);
    localparam int CNT_W = $clog2(DEPTH+1);

    logic [DATA_W-1:0] storage [0:DEPTH-1];
    logic [PTR_W-1:0] write_ptr, read_ptr;
    logic [CNT_W-1:0] count;
    logic push, pop;

    assign s_ready   = (count < DEPTH);
    assign m_valid   = (count > 0);
    assign m_data    = storage[read_ptr];
    assign occupancy = count;
    assign push      = s_valid && s_ready;
    assign pop       = m_valid && m_ready;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            write_ptr <= '0;
            read_ptr  <= '0;
            count     <= '0;
        end else begin
            // TODO 1 (Day 3): if push, store s_data at storage[write_ptr].
            // TODO 2 (Day 3): if push, advance write_ptr modulo DEPTH.
            // TODO 3 (Day 4): if pop, advance read_ptr modulo DEPTH.
            // TODO 4 (Day 4): update count:
            //   push only: +1, pop only: -1, both/neither: unchanged.
            // TODO 5 (Day 5): test reset, empty/full, stalls and simultaneous use.
        end
    end
endmodule
