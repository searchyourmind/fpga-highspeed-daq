# Week 1 - detailed learning and implementation tasks

## Day 1 - Environment + first PASS (60-90 minutes)
- Install a SystemVerilog simulator and cocotb; see root README.
- Read `rtl/counter.sv`, then run `make smoke` and inspect the test output.
- Identify which statement is combinational vs sequential and what reset does.
- In your own words: what happens when `enable = 0`?

## Day 2 - RTL fundamentals (60-90 minutes)
- Edit the counter from width 8 to width 4 and run tests (restore width 8 after).
- Add a second cocotb test checking hold while `enable = 0`.
- Learn `logic`, `always_ff`, nonblocking `<=`, edge-triggered reset and counters.
- Optional: use `verilator --lint-only --top-module counter rtl/counter.sv`.

## Day 3 - FIFO write side (90 minutes)
- Read `rtl/stream_fifo.sv` and the interface contract.
- Draw a FIFO state table: empty / middle / full.
- Implement TODO 1 and TODO 2 (write memory and advance write pointer).
- Draw what occupancy should be after 3 writes and no reads.
- Do NOT force count to 1 each time; it must reflect the number stored.

## Day 4 - FIFO read side and occupancy (90-120 minutes)
- Implement TODO 3 and TODO 4.
- Handle push-only, pop-only, simultaneous, and neither operations.
- Run `make fifo`; fix the *first* failing assertion and rerun.
- Test first-in-first-out order with at least 4 known words.

## Day 5 - Verification, not just happy path (90 minutes)
- Run all four tests (basic, full, randomized, reset).
- Explain why a producer can't change its value while stalled.
- Confirm `occupancy` never exceeds 8 and data are neither lost nor duplicated.
- Generate a waveform if possible and highlight a full-buffer stall.
- Add one new negative test of your own.

## Day 6 - DDR and PCIe reading (60 minutes)
- Draw where the FIFO will sit between a sensor and a DDR writer.
- Define four future *abstract* signals: memory_write_address,
  memory_write_data, memory_write_valid, memory_write_ready.
- Compare burst memory access against FIFO push/pop.
- Read about PCIe DMA as a host transfer, but do not implement a PCIe PHY.
- Make a one-page diagram of future Sensor -> FIFO -> DDR -> DMA -> PCIe.

## Day 7 - Portfolio milestone (60-90 minutes)
- Run `make smoke`, `make fifo`, and `make lint`.
- Summarize each test and describe what it proves.
- Include a console log and, if available, a timing waveform screenshot.
- `git init`, commit with message `Implement synchronous FIFO and cocotb tests`.
- In README, state accurately: RTL functional simulation only, not real FPGA.

## Acceptance criteria
- PASS: counter simulation.
- PASS: FIFO basic order, full-and-resume, deterministic randomized backpressure,
  and reset flush.
- No unreviewed lint errors; document exceptions.
- Your own notes explaining simultaneous push+pop and output stability.
- Source and tests in Git; no false claim of DDR, PCIe or FPGA hardware proof.
