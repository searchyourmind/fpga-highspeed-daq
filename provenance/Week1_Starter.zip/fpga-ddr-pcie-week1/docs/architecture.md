# System architecture and scope

Week 1 (real implementation):

    Python cocotb producer -> synchronous 16-bit x 8 FIFO -> Python cocotb consumer
                                     |
                                     +--> scoreboard + randomized backpressure

The producer represents a synthetic sensor stream. The consumer represents a future
DDR controller interface or DMA engine, but it is NOT a DDR or PCIe controller.

Later stages (conceptual only, not implemented):

    Sensor/Camera -> AXI-style stream -> FIFO -> DDR controller -> DDR memory
                                                   |
                                                   +--> DMA -> PCIe endpoint -> PC

This future system needs a target FPGA, physical memory interface controller/PHY,
PCIe IP/core, and device-specific timing constraints to become real hardware.
Pure behavioral models cannot validate DDR signal training or PCIe SerDes eye margins.

## Week 1 interface

| Port | Direction | Meaning |
|---|---|---|
| clk | input | common clock |
| rst_n | input | active-low asynchronous reset |
| s_data[15:0] | input | source data word |
| s_valid | input | source has a valid word |
| s_ready | output | FIFO has space |
| m_data[15:0] | output | oldest buffered word |
| m_valid | output | FIFO has at least one word |
| m_ready | input | sink can consume a word |
| occupancy | output | buffered word count 0..8 |

Only a rising clock edge with valid && ready transfers a word.
A producer MUST hold s_valid and s_data constant while s_valid && !s_ready.
The FIFO MUST hold m_valid and m_data constant while m_valid && !m_ready.

Design choice: when full, this starter FIFO does not allow a push until an entry
has been popped in a previous cycle. A more advanced design can optimize this.
